package exercise_Nam;

public class main {
    public static void main(String[] args) {
        CircleList circleList = new CircleList();
        circleList.input();
        circleList.output();
        circleList.maxArea();
    }
}
