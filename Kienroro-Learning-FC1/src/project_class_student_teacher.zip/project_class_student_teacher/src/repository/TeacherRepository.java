package repository;

public interface TeacherRepository {
}
