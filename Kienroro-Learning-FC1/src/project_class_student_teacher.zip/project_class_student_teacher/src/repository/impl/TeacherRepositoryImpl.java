package repository.impl;

import repository.TeacherRepository;

public class TeacherRepositoryImpl implements TeacherRepository {
}
