package service;

public interface TeacherService {
}
