package service.impl;

import repository.TeacherRepository;

public class TeacherServiceImpl implements TeacherRepository {
}
